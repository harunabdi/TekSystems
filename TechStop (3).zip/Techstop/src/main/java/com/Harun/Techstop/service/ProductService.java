package com.Harun.Techstop.service;

import com.Harun.Techstop.Entity.Product;
import com.Harun.Techstop.Repository.ProductRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Services for product: add, remove, fetch update
 */
@Service
public class ProductService {
    @Autowired
    private ProductRepo productRepo;

    public List<Product> getAll(){
        return productRepo.findAll();
    }
    public void addProduct(com.Harun.Techstop.Entity.Product product){productRepo.save(product); }
    public void deleteById(int id){productRepo.deleteById(id); }
    public Optional<Product> getById(int id){return productRepo.findById(id); }
   
}
