package com.Harun.Techstop.entity;

import org.junit.jupiter.api.Test;

import com.Harun.Techstop.Entity.Role;
import com.Harun.Techstop.Entity.User;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

class RoleTest {
    /**
     * Methods under test:
     *
     
     * </ul>
     */
    @Test
    void testConstructor() {
        Role actualRole = new Role();
        actualRole.setId(1);
        actualRole.setName("Name");
        ArrayList<User> userList = new ArrayList<>();
        actualRole.setUsers(userList);
        assertEquals(1, actualRole.getId());
        assertEquals("Name", actualRole.getName());
        assertSame(userList, actualRole.getUsers());
    }
}

